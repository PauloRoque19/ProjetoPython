import time
listaUsuario=[["Henrique","Henrique10"],["Paulo","Paulo10"],["Roque","Roque10"]]
listaReunião=["MiniCurso"]



def cadastroUsuario():
    receberUsuarios = []
    loginCadastro = input("Digite um login para cadastro: ")
    senhaCadastro = input("Digite uma senha para cadastro: ")

    if loginCadastro == "" or senhaCadastro == "":
        print("Login ou senha está em branco.")
        cadastroUsuario()

    else:
        receberUsuarios.append(loginCadastro)
        receberUsuarios.append(senhaCadastro)
        listaUsuario.append(receberUsuarios)
        arq = open("SalvandoUsuarios", "a")
        arq.write(loginCadastro+" ")
        arq.write(senhaCadastro+" ")
        arq.write("\n")
        arq.close()
        print("Conta Cadastrada com Sucesso.")

        print(listaUsuario)
    v1 = input("Você deseja ir para o Menu? Digite (sim) para ir para menu (não) para fazer um novo cadastro")


    if v1 == "sim":
        MenuComum()
    else:
        cadastroUsuario()


def MenuComum():
    print("----------- MENU COMUM ------------")
    print("- 1 para Cadastrar Usuario   -")
    print("- 2 para cadastrar Reuniões  -")
    print("- 3 Para Logar no Sistema    -")
    print("- 4 Para Criar Ata de Reunião -")
    print("- 5 Para Olhar Ata de Reunião -")

    print("-----------------------------")
    print()
    opcao = int(input("Opção: "))
    if opcao == 1:
       cadastroUsuario()
    elif opcao == 3:
         logar()
    elif opcao == 4:
        criarAtasDeReuniões()
    elif opcao == 5:
        visualizarAtasDeReuniões()

def MenuCoor():
    print("----------- MENU COOR ------------")
    print("- 1 para Cadastrar Usuario  -")
    print("- 2 para cadastrar Reuniões -")
    print("- 3 Para Logar no Sistema   -")
    print("-----------------------------")
    print()
    opcao = int(input("Opção: "))
    if opcao == 1:
       cadastroUsuario()
    elif opcao == 3:
         logar()
def MenuGest():
    print("----------- MENU GESTOR ------------")
    print("- 1 para Cadastrar Usuario  -")
    print("- 2 para cadastrar Reuniões -")
    print("- 3 Para Logar no Sistema   -")
    print("-----------------------------")
    print()
    opcao = int(input("Opção: "))
    if opcao == 1:
       cadastroUsuario()
    elif opcao == 3:
         logar()

def criarAtasDeReuniões():
    v1=str(input("Escreva nome da reunião: "))
    if v1 in listaReunião:
        arq = open(v1,"w")
        n=str(input("Digite algo: "))
        arq.write(n)
        arq.close()

    v2=input("Digite (sim) para voltar para o menu: ")
    print("...")
    time.sleep(2)
    if v2 == "sim":
        MenuComum()
def visualizarAtasDeReuniões():

    v1=str(input("Escreva nome da ata que queira visualizar: "))
    if v1 in listaReunião:
        manipulador = open(v1,'r')
    #print("\nMétodo read():\n")
        print(manipulador.read()+"\n")
        manipulador.seek(0)
    else:
        visualizarAtasDeReuniões()
    v2=input("Digite (sim ) para voltar para menu: ")
    if v2 == "sim":
        MenuComum()

def logar():
    loginLogar=input("Digite Seu Usuario: ")
    senhaLogar=input("Digite Sua Senha: ")
    if loginLogar == "COOR":
        MenuCoor()
    elif loginLogar == "GEST":
        MenuGest()
    for l in range(len(listaUsuario)):
        for c in range(len(listaUsuario[l])):
            if loginLogar in listaUsuario[l] and senhaLogar in listaUsuario[l]:
                MenuComum()





logar()