
listaUsuario=["user","adm123","admin","admin","admin1","12345"]
login=""
senha=""


def cadastroUsuario():
    receberUsuarios = []
    loginCadastro = input("Digite um login para cadastro: ")
    senhaCadastro = input("Digite uma seha para cadastro: ")

    if loginCadastro == "" or senhaCadastro == "":
        print("Login ou senha está em branco.")
        cadastroUsuario()
    else:
        receberUsuarios.append(loginCadastro)
        receberUsuarios.append(senhaCadastro)
        listaUsuario.append(receberUsuarios)
        print("Conta Cadastrada com Sucesso.")

        print(listaUsuario)
    v1 = input("Você deseja ir para o Menu? Digite (sim) para ir para menu (não) para fazer um novo cadastro")


    if v1 == "sim":
        Menu()
    else:
        cadastroUsuario()





def Menu():
    print("----------- MENU ------------")
    print("- 1 para Cadastrar Usuario  -")
    print("- 2 para cadastrar Reuniões -")
    print("- 3 Para Logar no Sistema   -")
    print("-----------------------------")
    print()
    opcao = int(input("Opção: "))
    if opcao == 1:
       cadastroUsuario()
    elif opcao == 3:
         logar()


def logar():
    print("------------ Login -----------")
    usuario = input("Usuario: ")
    password = input("Senha: ")
    print("------------------------------")
    if usuario in listaUsuario[0] and password in listaUsuario[1]:
        print("logado1")
        Menu()
    elif usuario in listaUsuario[2] and password in listaUsuario[3]:
        print("logado2")
    elif usuario in listaUsuario[4] and password in listaUsuario[5]:
        print("logado3")
    else:
        listaUsuario.append(login)
        listaUsuario.append(senha)
        for i in range(len(listaUsuario)):
            if login in listaUsuario[i]:
                print("Cadastrado e Logado!")
                Menu()


logar()


