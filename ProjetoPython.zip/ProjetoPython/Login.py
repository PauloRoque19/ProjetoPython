listaUsuario=[]

def cadastroUsuario():
    receberUsuarios=[]
    loginCadastro=input("Digite um login para cadastro: ")
    senhaCadastro=input("Digite uma seha para cadastro: ")


    if loginCadastro == "" or senhaCadastro == "":
        print("Login ou senha está em branco.")
        cadastroUsuario()
    else:
        receberUsuarios.append(loginCadastro)
        receberUsuarios.append(senhaCadastro)
        listaUsuario.append(receberUsuarios)
        print("Conta Cadastrada com Sucesso.")

        print(listaUsuario)
    v1=input("Você deseja fazer outro cadastro? digite (sim) se não digite (não). ")
    if v1 == "sim":
        cadastroUsuario()
    else:
        print("OK")


cadastroUsuario()



