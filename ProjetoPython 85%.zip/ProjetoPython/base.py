from dados import *

def inicio():
	#LOOP
	while True:
		#carrega todos os usuarios cadastrados no arquivo txt
		lista_de_usuarios = ler_usuarios()
		#envia para o metodo login a lista de usuarios para ser feita a checkagem
		login(lista_de_usuarios)

def login(lista_de_usuarios):
	#lê o nome do usuario e a senha
	nome = input('>>> Entre com o nome do Usuário:')
	senha = input('>>> Digite sua senha:')
	#verifica se o nome está contido na lista criada extraindo da lista de usuarios apenas os logins dos usuarios
	if nome in [usuario[0] for usuario in lista_de_usuarios]:
		#compara o vetor [nome, senha] com os vetores criados ma lista com os pares
		if [nome, senha] in [[usuario[0], usuario[1]] for usuario in lista_de_usuarios]:
			#.index(nome)-> retorna o indice do elemento que contem 'nome'
			#index é aplicado a lista criada com apenas os nomes
			#dessa combinação resulta o indice do vetor quando for logado com sucesso
			usuario = lista_de_usuarios[[item[0] for item in lista_de_usuarios].index(nome)]
			#chama a função que exibe uma especie de login
			page_usuario(usuario)
		else:
			print('-==-==-==-==-==-==-==-==')
			print('!!! Senha Incorreta !!!')
			print('-==-==-==-==-==-==-==-==\n\n\n')
	else:
		#caso o usuario não esteja cadastrado será sugerido um cadastro
		if(input(">>> Deseja cadastrar usuario <'sim' para continuar>: ")=='sim'):
			usuario_novo = [nome, senha, input(">>> Tipo do usuário <'coordenador', 'gerente' ou 'comum'>:")]
			criar_item(usuario_novo)

def criar_item(item_novo):
	cadastrar_usuario(item_novo)

def page_usuario(usuario):
	print('-==-==-==-==-==-==-==-==')
	print('        Logado')
	print('-==-==-==-==-==-==-==-==')
	print("Seja bem vindo, {0}".format(usuario[0]))
	print(usuario[2])
	if(usuario[2]=='gerente'):
		page_usuario_gerente()
	elif(usuario[2]=='coordenador'):
		page_usuario_coordenador()
	elif (usuario[2]=='comum'):
		page_usuario_comum()
	else:
		print('Usuário ainda não confirmado\n\n\n')

def page_usuario_comum():
	print('Usuario Comum\n\n\n')


def page_usuario_gerente():
	print('Gerente\n\n\n')
	

def page_usuario_coordenador():
	print('Coordenador\n\n\n')


inicio()
