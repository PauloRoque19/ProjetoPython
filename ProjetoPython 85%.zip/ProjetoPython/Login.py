import time


saberusuario = []
listaUsuario = [["COMUM","COMUM"],["COOR","COOR"],["GEST","GEST"]]
listaReunião = ["MiniCurso"]
listaSala = ["sala01", "sala02", "sala03", "sala04", "sala05", "sala06", "sala07", "sala08", "sala09"]


def criarLocaisReunioes():
    nomesala = input("Digite o nome da sala: ")
    if nomesala in listaSala:
        print("Sala já existe")
        criarLocaisReunioes()
    else:
        listaSala.append(nomesala)
        time.sleep(1)
        print("Local criado com Sucesso.")
    v1 = input("Digite (sim) para voltar ao menu.")
    if v1 == "sim":
        MenuGest()
    else:
        criarLocaisReunioes()


def editarAtasReunioesCoor():
    v1 = str(input("Escreva nome da Ata ou Reunião: "))
    print("...")
    time.sleep(1)
    if v1 in listaReunião:
        arq = open(v1, "w")
        n = str(input("Digite algo: "))
        arq.write(n)
        arq.close()

    v2 = input("Digite (sim) para voltar para o menu: ")
    print("...")
    time.sleep(2)
    if v2 == "sim":
        MenuCoor()


def criarReuniao():
    v1 = []
    tema = input("Tema da reunião: ")
    horario = input("Horario da reunião: ")
    data = input("Data da reunião: ")
    local = input("Local da Reunião")
    addparti = input("Participantes: ")
    sn = input("Senha de segurança:  ")

    if tema == "" or horario == "" or data == "" or sn == "":
        criarReuniao()
    else:
        v1.append(tema)
        v1.append(horario)
        v1.append(data)
        v1.append(sn)
        listaReunião.append(v1)
    v2 = input("Digite (sim) para voltar para o menu: ")
    print("...")
    time.sleep(2)

    if v2 == "sim" and "COOR" in saberusuario:
        MenuCoor()
    elif v2 == "sim":
        MenuComum()


def cadastroUsuario():

    loginCadastro = input("Digite um login para cadastro: ")
    senhaCadastro = input("Digite uma senha para cadastro: ")

    arq = open("SalvandoUsuarios", "r")
    for linha in arq:
        if loginCadastro in linha:
            print("Usuario já existe")
            cadastroUsuario()
    arq.close()

    if loginCadastro == "" or senhaCadastro == "":
        print("Login ou senha está em branco.")
        cadastroUsuario()

    else:

        arq = open("SalvandoUsuarios", "a")
        arq.write(loginCadastro + " ")
        arq.write(senhaCadastro + " ")
        arq.write("\n")
        arq.close()
        arq1= open("listaParticipantes.txt","a")
        arq1.write(loginCadastro+"\n")
        arq1.close()
        print("Conta Cadastrada com Sucesso.")


    v1 = input("Você deseja ir para o Menu? Digite (sim) para ir para menu (não) para fazer um novo cadastro")

    if v1 == "sim":
        MenuComum()
    else:
        cadastroUsuario()


def MenuComum():
    print("----------- MENU COMUM ------------")

    print("- 1 para CADASTRAR USUARIOS          -")
    print("- 2 para CONFIRMAR PRESENÇA          -")
    print("- 3 para VISUALIZAR REUNIÕES CONFIRMDAS-")
    print("- 4 Para VISUALIZAR ATAS REUNIÕE     -")
    print("- 5 Para CRIAR UMA REUNIÃO           -")
    print("- 6 Para CRIAR ATAS e EDITAR REUNIÕES -")
    print("- 7 Para BAIXAR ATAS REUNIÕES        -")
    print("- 0 Para SAIR DO E-MEETING           -")

    print("-----------------------------")
    print()
    opcao = int(input("Opção: "))
    if opcao == 1:
        cadastroUsuario()
    # elif opcao == 2:

    elif opcao == 3:
        criarAtasDeReuniões()
    elif opcao == 4:
        visualizarAtasDeReuniões()
    # elif opcao == 5:

    elif opcao == 0:
        exit()


def MenuCoor():
    print("----------- MENU COOR ------------")
    print("- 1 para Visualizar Reuniões confirmada presença  -")
    print("- 2 para confirmar presença em reunião            -")
    print("- 3 Para Criar Reuniões                           -")
    print("- 4 Para Editar Atas Global                       -")
    print("- 5 Para Realocar Reunião                         -")
    print("- 6 Para Add Participantes em Reuniões.           -")
    print("- 0 Para Sair do Sistema ")
    print("-----------------------------")
    print()
    opcao = int(input("Opção: "))
    if opcao == 1:
        cadastroUsuario()
    elif opcao == 2:
        logar()
    elif opcao == 3:
        criarReuniao()
    elif opcao == 4:
        editarAtasReunioesCoor()
    # elif opcao == 5:
    elif opcao == 0:
        exit()


def MenuGest():
    print("----------- MENU GESTOR ------------")
    print("- 1 Confirmar Local da Reunião              -")
    print("- 2 Para Cadastrar Novos espaços de Reunião -")

    print("-----------------------------")
    print()
    opcao = int(input("Opção: "))
    if opcao == 1:
        cadastroUsuario()
    elif opcao == 2:
        criarLocaisReunioes()
    elif opcao == 0:
        exit()


def criarAtasDeReuniões():
    v1 = str(input("Escreva nome da reunião: "))
    if v1 in listaReunião:
        arq = open(v1, "w")
        n = str(input("Digite algo: "))
        arq.write(n)
        arq.close()

    v2 = input("Digite (sim) para voltar para o menu: ")
    print("...")
    time.sleep(2)
    if v2 == "sim":
        MenuComum()


def visualizarAtasDeReuniões():
    v1 = str(input("Escreva nome da ata que queira visualizar: "))
    if v1 in listaReunião:
        manipulador = open(v1, 'r')
        # print("\nMétodo read():\n")
        print(manipulador.read() + "\n")
        manipulador.seek(0)
    else:
        visualizarAtasDeReuniões()
    v2 = input("Digite (sim ) para voltar para menu: ")
    if v2 == "sim":
        MenuComum()


def logar():
    loginLogar = input("Digite Seu Usuario: ")
    senhaLogar = input("Digite Sua Senha: ")
    saberusuario.append(loginLogar)
    for l in range(len(listaUsuario)):
        for c in range(len(listaUsuario[l])):
            if loginLogar =="GEST" in listaUsuario[l] and senhaLogar == "GEST" in listaUsuario[l]:
                MenuGest()
            elif loginLogar == "COOR" in listaUsuario[l] and senhaLogar == "COOR" in  listaUsuario[l]:
                MenuCoor()
            elif loginLogar == "COMUM" in listaUsuario[l] and senhaLogar == "COMUM" in listaUsuario[l]:
                MenuComum()

    arq = open("SalvandoUsuarios", "r")

    for linha in arq:
        if loginLogar in linha and senhaLogar in linha:
            print("\n" + "Usuario", loginLogar, " Acessado")
            MenuComum()
        else:
            print(" ")

    arq.seek(0)
    arq.close()


print(" SISTEMA E-MEETING")
logar()



