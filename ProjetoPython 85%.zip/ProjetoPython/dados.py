def ler_usuarios():
	try:
		#abre o arquivo no modo leitura
		arquivo = open('usuarios.txt', 'r')
		conteudo = []
		for linha in arquivo.readlines():
			#linha e uma string 
			#split transforma p string em uma lista considerando ' ' como separador
			#linha[:-1] exclui o caracter '\n' responsavel pela quebra de linha
			usuario = linha[:-1].split(' ')
			#adiciona uma lista com os dados tratados
			conteudo.append(usuario)

		#retorna o conteudo do arquivo caso ele exista
		return conteudo
	except Exception as e:
		#retorna uma lista vazia caso o arquivo usuarios.txt não exista
		return []
ler_usuarios()

def cadastrar_usuario(usuario):
	#carrega os dados que estão no arquivo txt
	lista = ler_usuarios()

	#abre o arquivo no modo de escrever
	arquivo = open('usuarios.txt', 'w')
	#adiciona a lista o usuario recebido para ser cadastrado
	lista.append(usuario)

	conteudo = []
	for item in lista:
		#trata os elementos da lista para serem inseridos no arquivo de forma adequada
		linha = "{0} {1} {2}\n".format(item[0], item[1], item[2])
		#cria um lista contendo strings em que cada string representa um usuário
		conteudo.append(linha)
	#escreve os multiplos usuarios no arquivo txt
	arquivo.writelines(conteudo)
	#fecha o qrquivo
	arquivo.close()

