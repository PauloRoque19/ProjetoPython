'''
arq = open('SalvandoUsuarios', 'r')  #abre o arquivo
texto = []  #declaro um vetor
matriz = [] #declaro um segundo vetor
texto = arq.readlines() #quebra as linhas do arquivo em vetores
print("vetor texto -> ",texto) #aqui eu mostro
print("")

for i in range(len(texto)):          #esse for percorre a posições dp vetor texto
    matriz.append(texto[i].split())  #aqui eu quebro nos espasos das palavras

print("vetor matriz -> ",matriz) #mostra o vertor com um conjunto de vetores
print("")

for i in range(len(texto)):          #mostra quedrando em linhas
    print(matriz[i])


arq.close()
'''
'''
matriz=[]
print(matriz)
arq = open("SalvandoUsuarios.txt","r")
texto=[]
for linha in arq:
    linha = linha.rstrip()
    texto = linha
    matriz.append(texto)
arq.seek(0)

arq.close()
print(matriz)
'''
vetor=[]
var=input("Digite algo")
var2=input("Digite algo")
var3=input("Digite algo")
vetor = var + var2 + var3
print(vetor)
