import time
from reportlab.pdfgen import canvas


saberusuario = []
listaUsuario = [["@ROOTCOMUM","COMUM"]]
listaReunião = [["MiniCurso"]]
listaSala = ["sala01"]

#RODANDO
def lerDados():
    #LER ARQUIVOTXT DE USUARIOS E ENVIAR DADOS PARA A MATRIZ USUARIOS
    arq = open("SalvandoUsuarios.txt", "r")
    textousuarios = []

    for linha in arq:
        linha = linha.split()
        textousuarios = linha
        listaUsuario.append(textousuarios)
    arq.seek(0)

    arq.close()
    #LER ARQUIVOTXT DE REUNIOES E ENVIAR DADOS PARA A MATRIZ REUNIOES
    arq1 = open("listaReuniões.txt","r")
    textoreunioes = []

    for linha in arq1:
        linha = linha.split()
        textoreunioes = linha
        listaReunião.append(textoreunioes)
    arq1.seek(0)
    arq1.close()
    #LER ARQUIVO DE SALAS E ENVIAR DADOS PARA A MATRIZ SALA
    arq2 = open("listaSalas.txt","r")
    textosalas = []

    for linha in arq2:
        linha = linha.rstrip()
        textosalas = linha
        listaSala.append(textosalas)
    arq2.seek(0)
    arq2.close()



#Cria locais de Reuniões   #RODANDO
def criarLocaisReunioes():
    nomesala = input("Digite o nome da sala: ")

    arq = open("listaSalas.txt","r+")
    for linha in arq:
        if nomesala in linha:
            print("Sala já existe")
            criarLocaisReunioes()
    else:
        arq.write(nomesala+"\n")
        arq.close()

        time.sleep(1)
        print("Local criado com Sucesso.")
    v1 = input("Digite (sim) para voltar ao menu.")
    if v1 == "sim":
        MenuGest()
    else:
        criarLocaisReunioes()

#Serve para reescrever um arquivo.txt que serve como ata.
def editarAtasReunioesCoor():
    print(listaReunião)
    v1 = str(input("Escreva nome da Ata ou Reunião: "))
    print("...")
    time.sleep(1)

    arq = open(v1, "w")
    n = str(input("Digite algo: "))
    arq.write(n)
    arq.close()

    v2 = input("Digite (sim) para voltar para o menu: ")
    print("...")
    time.sleep(2)
    if v2 == "sim":
        MenuCoor()

#Serve para criar uma reunião e jogar os dados para um arquivotxt #Rodando
def criarReuniao():
    v1 = []


    tema = input("Tema da reunião (SEM ESPAÇO) : ")
    horario = input("Horario da reunião: ")
    data = input("Data da reunião: ")
    print(listaSala)
    sala=input("Digite a sala: ")
    listaSala.remove(sala)
    local = input("Local da Reunião: ")
    #abre o arquivo em modo leitura e mostrar os usuarios cadastrados
    manipulador = open("listaParticipantesUsuariosSistema.txt", 'r')
    print(manipulador.read())
    manipulador.seek(0)
    addparti = int(input("Quantidade de Participantes: "))
    sn = input("Senha de segurança:  ")
    if tema == "" or horario == "" or data == "" or sn == "" or sala == "" or local == "" or addparti == "":
        criarReuniao()
    for i in range(addparti):
        participantes=input("Digite o nome do participante: ")
        #criar um arquivo para armazenar os participantes convidados
        arq = open(tema + "Participantes", "a")
        arq.write("Lista de participantes")
        arq.write("\n"+participantes)
        arq.close()
       #manda o convite para o usuario
        arq1=open(participantes,"a")
        arq1.write("Convidado para reuniao:"+tema+" "+"Horario: "+horario+" "+"Data: "+data+" "+"Sala: "+sala+" "+"Local: "+local+"\n")
        arq1.close()

    else:
        #lista de reunioes global
        arq2 = open("listaReuniões.txt","a")
        arq2.write("\n"+tema+" ")
        arq2.write(sn+" ")
        arq2.write(local)
        arq2.close()


    v2 = input("Digite (sim) para voltar para o menu: ")
    print("...")
    time.sleep(2)

    if v2 == "sim" and "COOR" in saberusuario:
        MenuCoor()
    elif v2 == "sim":
        MenuComum()

#Cadastro simples de usuarios que os dados será jogado para um arquivotxt que depois jogará os dados para uma matriz
def cadastroUsuario():
    receberUsuarios=[]
    loginCadastro = input("Digite um login para cadastro: ")
    senhaCadastro = input("Digite uma senha para cadastro: ")

    for i in range(len(listaUsuario)):
        for c in range(len(listaUsuario[i])):
            if loginCadastro in listaUsuario[i]:
                print("Usuario já existente.")
                cadastroUsuario()

    if loginCadastro == "" or senhaCadastro == "":
        print("Login ou senha está em branco.")
        cadastroUsuario()


    else:
        receberUsuarios.append(loginCadastro)
        receberUsuarios.append(senhaCadastro)
        arq = open("SalvandoUsuarios.txt", "a")
        arq.write(loginCadastro + " ")
        arq.write(senhaCadastro + " ")
        arq.write("\n")
        arq.close()
        arq1= open("listaParticipantesUsuariosSistema.txt","a")
        arq1.write(loginCadastro+"\n")
        arq1.close()
        arq2 = open(loginCadastro,"w")
        arq2.write("Reunioes Convidadas"+"\n")
        arq2.close()
        arq3 = open(loginCadastro+"reunioesconfirmadas","a")
        arq3.write("Reunioes Confirmadas"+"\n")
        arq3.close()
        print("Conta Cadastrada com Sucesso.")


    v1 = input("Você deseja ir para o Menu? Digite (sim) para ir para menu (não) para fazer um novo cadastro")

    if v1 == "sim":
        MenuComum()
    else:
        cadastroUsuario()

# TA RODANDO MAS PRECISA MELHORAR ESSA MERDA
def criarAtasDeReuniõesCOMUM():
    vetor=[]

    v1 = str(input("Escreva nome da reunião ou ata: "))
    v2 = input("Digite a senha da sua reunião")

    for i in range(len(listaReunião)):
        for l in range(len(listaReunião[i])):
            if v1 in listaReunião[i][0] and v2 in listaReunião[i][1]:
                vetor.append(v1)
                vetor.append(v2)

            else:
                print(" ")
    if v1 in vetor[0] and v2 in vetor[1]:

        arq = open(v1, "w")
        n = str(input("Digite algo: "))
        arq.write(n)
        arq.close()

    v2 = input("Digite (sim) para voltar para o menu: ")
    print("...")
    time.sleep(2)
    if v2 == "sim":
        MenuComum()

def visualizarAtasDeReuniões():
    v1 = str(input("Escreva nome da ata que queira visualizar: "))
    if v1 in listaReunião:
        manipulador = open(v1, 'r')
        print(manipulador.read() + "\n")
        manipulador.seek(0)
        manipulador.close()
        #AQUIIIIIIIIIIIII TA O ERROR  EM MANIPULADOR CLOSE SE CASO VIER DA ERROR *@*(#)!()#!()#*(!#*()!*()#()#!(*#)!*#)(!
    else:
        visualizarAtasDeReuniões()
    v2 = input("Digite (sim ) para voltar para menu: ")
    if v2 == "sim":
        MenuComum()

def confirmarPresencaReuniao():
    var = input("Digite seu usuario: ")
    arq = open(var,'r')
    print(arq.read())
    arq.close()
    var1 = input("Digite o nome da reunião que você vai confirmar presença: ")
    var2 = input("Escreva seu nome e (CONFIRMAR OU NEGAR)")
    arq1 = open(var1+"ParticipantesConfirmados.txt",'a')
    arq1.write("\n"+var2)
    arq1.close()
    arq2 = open(var+"reunioesconfirmadas","a")
    arq2.write(var1)
    arq2.close()
#Rodando #metodo para visualizar reunioes confirmadas
def visualizar_reunioes_confirmadas():
    var=input("Digite seu login: ")
    print("")
    #abre o arquivo
    arq=open(var+"reunioesconfirmadas",'r')
    #ler o arquivo
    print(arq.read())
    arq.close()

    v1=input("Digite (sim) para voltar ao menu")

    if v1 == "sim" and saberusuario == "COOR":
        MenuCoor()
    elif v1 == "sim" and saberusuario != "COOR":
        MenuComum()

def alterarLocalReuniao():
    nreuniao=input("Digite o nome da reuniao")
    validador=0
    for l in range(len(listaReunião)):
        for c in range(len(listaReunião[l])):
            if nreuniao in listaReunião[l]:
                validador = 1
    if validador == 0:
        print("Reunião não encontrada")
    else:
        contador = 0
        arq = open(nreuniao+"Participantes")
        for linha in arq:
            contador = contador + 1
        contador = contador - 1
        print("Número de participantes é :",contador)
        arq.close()
        novolocal = input("Digite novo local: ")
        for i in range(contador):
            nomearquivo = input("Nome do participante : ")
            manipulador = open(nomearquivo,"a")
            manipulador.write("Alterado Local da Reuniao: "+ nreuniao +"Para: "+ novolocal+"\n")
            manipulador.close()

def baixarAtas():
    nomeata = input("Digite nome da ata: ")
    arq = open(nomeata,"r")

    cnv = canvas.Canvas(nomeata+".pdf")
    cnv.drawString(150, 450, arq.read())
    cnv.save()
    return 0
    arq.close()


def MenuComum():
    print("----------- MENU COMUM ------------")

    print("- 1 para CADASTRAR USUARIOS             -")
    print("- 2 para CONFIRMAR PRESENÇA             -")
    print("- 3 para VISUALIZAR REUNIÕES CONFIRMADAS-")
    print("- 4 Para VISUALIZAR ATAS REUNIÕES       -")
    print("- 5 Para CRIAR UMA REUNIÃO              -")
    print("- 6 Para CRIAR ATAS ou EDITAR REUNIÕES   -")
    print("- 7 Para BAIXAR ATAS REUNIÕES           -")

    print("- 0 Para SAIR DO E-MEETING           -")

    print("-----------------------------")
    print()
    opcao = int(input("Opção: "))
    if opcao == 1:
        cadastroUsuario()
    elif opcao == 2:
        confirmarPresencaReuniao()

    elif opcao == 3:
        visualizar_reunioes_confirmadas()
    elif opcao == 4:
        visualizarAtasDeReuniões()
    elif opcao == 5:
        criarReuniao()

    elif opcao == 6:
        criarAtasDeReuniõesCOMUM()
    elif opcao == 7:
        baixarAtas()

    elif opcao == 0:
        exit()


def MenuCoor():
    print("----------- MENU COOR ------------")
    print("- 1 para Visualizar Reuniões confirmada presença  -")
    print("- 2 para confirmar presença em reunião            -")
    print("- 3 Para Criar Reuniões                           -")
    print("- 4 Para Editar Atas Global                       -")
    print("- 5 Para Realocar Reunião                         -")
    print("- 6 Para Add Participantes em Reuniões.           -")
    print("- 0 Para Sair do Sistema ")
    print("-----------------------------")
    print()
    opcao = int(input("Opção: "))
    if opcao == 1:
        visualizar_reunioes_confirmadas()
    elif opcao == 2:
        confirmarPresencaReuniao()
    elif opcao == 3:
        criarReuniao()
    elif opcao == 4:
        editarAtasReunioesCoor()
    elif opcao == 5:
        alterarLocalReuniao()
    # elif opcap == 6:

    elif opcao == 0:
        exit()


def MenuGest():
    print("----------- MENU GESTOR ------------")
    print("- 1 Confirmar Local da Reunião              -")
    print("- 2 Para Cadastrar Novos espaços de Reunião -")
    print("- 0 Para SAIR DO SISTEMA -")


    print("-----------------------------")
    print()
    opcao = int(input("Opção: "))
    if opcao == 1:
        cadastroUsuario()
    elif opcao == 2:
        criarLocaisReunioes()
    elif opcao == 0:
        exit()





def logar():
    loginLogar = input("Digite Seu Usuario: ")
    senhaLogar = input("Digite Sua Senha: ")
    saberusuario.append(loginLogar)

    for l in range(len(listaUsuario)):
        for c in range(len(listaUsuario[l])):
            if loginLogar =="@ROOTGEST" and senhaLogar == "GEST" :
                MenuGest()
            elif loginLogar =="@ROOTCOOR"  and senhaLogar =="COOR" :
                MenuCoor()
            elif loginLogar in  listaUsuario[l] and senhaLogar  in listaUsuario[l][1]:
                MenuComum()
    else:
        logar()

print(" SISTEMA E-MEETING")
lerDados()

logar()



